# loggingutil

Advanced logging utility with support for file rotation, JSON logging, exceptions, and async HTTP logging.